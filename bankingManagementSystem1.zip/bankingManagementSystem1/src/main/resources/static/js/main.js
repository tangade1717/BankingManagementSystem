import React from 'react';
import ReactDOM from 'react-dom';
import './index.css'; // Import your custom CSS file
import App from './App'; // Import your main App component
import reportWebVitals from './reportWebVitals';

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);
