package com.cdac.training.banking.demo.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class UserDTO {

	@NotNull(message = "{user.no.NULL}")
	@Min(value = 1000000000L, message = "{user.no.INVALID}")
	@Max(value = 9999999999L, message = "{user.no.INVALID}")
	private Long mobileNumber;

	@NotNull(message = "{userId.NULL}")
	@Pattern(regexp = "^U.*", message = "{user.Id.INVALID}")
	private String userId;

	@NotNull(message = "{user.name.NULL}")
	@Size(min = 3, max = 10, message = "{user.name.INVALID}")
	private String accountHolderName;

	@Pattern(regexp = "Male|Female", message = "{user.gender.INVALID}")
	private String gender;

	@Past(message = "{user.doj.INVALID}")
	private LocalDate dateOfBirth;

	@NotNull(message = "{user.password.NULL}")
	@Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d).+$", message = "{user.password.INVALID}")
	@Size(min = 5, max = 10, message = "{user.password.size.INVALID}")
	private String password;

	@Pattern(regexp = "^[a-zA-Z0-9_]+@[a-zA-Z]+\\.[a-z]{2,}$", message = "{user.mail.INVALID}")
	private String email;

	@NotNull(message = "{user.address.NULL}")
	@Size(min = 5, max = 50, message = "{user.address.INVALID}")
	private String communicationAddress;

	@Size(min = 10, max = 10, message = "{user.size.INVALID}")
	@Pattern(regexp = "^[A-Z]{5}\\d{4}[A-Z]{1}$", message = "{user.pan.INVALID}")
	private String pan;

	// Getters and Setters

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCommunicationAddress() {
		return communicationAddress;
	}

	public void setCommunicationAddress(String communicationAddress) {
		this.communicationAddress = communicationAddress;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}
}
