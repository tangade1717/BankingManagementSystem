package com.cdac.training.banking.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.security.auth.login.AccountException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cdac.training.banking.demo.dto.BankAccountDTO;
import com.cdac.training.banking.demo.dto.TransactionDTO;
import com.cdac.training.banking.demo.dto.UserDTO;
import com.cdac.training.banking.demo.entity.BankAccountEntity;
import com.cdac.training.banking.demo.entity.DigitalBankAccountEntity;
import com.cdac.training.banking.demo.entity.TransactionEntity;
import com.cdac.training.banking.demo.entity.UserEntity;
import com.cdac.training.banking.demo.repository.AccountRepository;
import com.cdac.training.banking.demo.repository.DigitalBankAccountRepository;
import com.cdac.training.banking.demo.repository.TransactionRepository;
import com.cdac.training.banking.demo.repository.UserRepository;
import com.cdac.training.banking.demo.utility.ExceptionConstants;
import com.cdac.training.banking.demo.utility.OTPUtility;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private DigitalBankAccountRepository digitalBankAccountRepository;

	@Autowired
	private TransactionRepository transactionRepository;

	@Autowired
	private OTPUtility otpUtility;

	@Override
	public String createAccount(BankAccountDTO accountDTO) throws AccountException {
		Optional<BankAccountEntity> optional = accountRepository.findById(accountDTO.getAccountNumber());

		if (optional.isPresent()) {
			throw new AccountException(ExceptionConstants.ACCOUNT_ALREADY_EXISTS);
		}

		UserEntity userEntity = new UserEntity();
		userEntity.setUserId(accountDTO.getUser().getUserId());
		userEntity.setAccountHolderName(accountDTO.getUser().getAccountHolderName());
		userEntity.setCommunicationAddress(accountDTO.getUser().getCommunicationAddress());
		userEntity.setDateOfBirth(accountDTO.getUser().getDateOfBirth());
		userEntity.setEmail(accountDTO.getUser().getEmail());
		userEntity.setGender(accountDTO.getUser().getGender());
		userEntity.setMobileNumber(accountDTO.getUser().getMobileNumber());
		userEntity.setPan(accountDTO.getUser().getPan());
		userEntity.setPassword(accountDTO.getUser().getPassword());

		BankAccountEntity accountEntity = new BankAccountEntity();
		accountEntity.setAccountNumber(accountDTO.getAccountNumber());
		accountEntity.setBankName(accountDTO.getBankName());
		accountEntity.setBalance(accountDTO.getBalance());
		accountEntity.setAccountType(accountDTO.getAccountType());
		accountEntity.setIfscCode(accountDTO.getIfscCode());
		accountEntity.setOpeningDate(accountDTO.getOpeningDate());

		accountEntity.setUserEntity(userEntity);
		// userRepository.save(userEntity); // Commented out because userEntity is saved
		// by accountEntity
		accountRepository.save(accountEntity);
		return "Account created " + accountEntity.getAccountNumber().toString();
	}

	@Override
	public List<BankAccountDTO> listAccounts(Long mobileNo) throws AccountException {
		List<BankAccountEntity> list = accountRepository.findByMobileNumber(mobileNo);
		List<BankAccountDTO> accountDTOs = new ArrayList<>();
		if (list.isEmpty()) {
			throw new AccountException("account.NOT_EXIST");
		}

		for (BankAccountEntity entity : list) {
			BankAccountDTO dto = new BankAccountDTO();
			dto.setAccountNumber(entity.getAccountNumber());
			dto.setAccountType(entity.getAccountType());
			dto.setBalance(entity.getBalance());
			dto.setBankName(entity.getBankName());
			dto.setIfscCode(entity.getIfscCode());
			dto.setOpeningDate(entity.getOpeningDate());

			UserDTO userDTO = new UserDTO();
			userDTO.setAccountHolderName(entity.getUserEntity().getAccountHolderName());
			userDTO.setCommunicationAddress(entity.getUserEntity().getCommunicationAddress());
			userDTO.setDateOfBirth(entity.getUserEntity().getDateOfBirth());
			userDTO.setEmail(entity.getUserEntity().getEmail());
			userDTO.setGender(entity.getUserEntity().getGender());
			userDTO.setMobileNumber(entity.getUserEntity().getMobileNumber());
			userDTO.setPan(entity.getUserEntity().getPan());
			userDTO.setUserId(entity.getUserEntity().getUserId());
			userDTO.setPassword(entity.getUserEntity().getPassword());
			dto.setUser(userDTO);
			accountDTOs.add(dto);
		}
		return accountDTOs;
	}

	@Override
	public String linkAccount(Long mobileNo, Long accountNo) throws AccountException {
		List<BankAccountEntity> accountEntityList = accountRepository.findByMobileNumber(mobileNo);
		BankAccountEntity bankAccountEntity = null;
		if (accountEntityList.isEmpty()) {
			throw new AccountException("account.NOT_EXIST");
		}

		for (BankAccountEntity entity : accountEntityList) {
			if (entity.getAccountNumber().equals(accountNo)) {
				bankAccountEntity = entity;
				break;
			}
		}

		if (bankAccountEntity == null) {
			throw new AccountException("account.MISMATCH");
		}

		String id = digitalBankAccountRepository.findLastById();
		String[] parts = id.split("-");
		String p1 = parts[0];
		String p2 = parts[1];

		int dId = Integer.parseInt(p2) + 1;
		String digitalId = p1 + "-" + dId;

		DigitalBankAccountEntity digitalBankAccountEntity = new DigitalBankAccountEntity();
		digitalBankAccountEntity.setDigitalBankingId(digitalId);
		digitalBankAccountEntity.setUser(bankAccountEntity.getUserEntity());
		digitalBankAccountEntity.setBankAccountEntity(bankAccountEntity);
		digitalBankAccountEntity.setAccountType(bankAccountEntity.getAccountType());

		if (digitalBankAccountRepository.findByAccountNo(accountNo) != null) {
			throw new AccountException("digitalId.EXIST");
		}

		digitalBankAccountRepository.save(digitalBankAccountEntity);

		return "Account linked successfully " + digitalBankAccountEntity.getDigitalBankingId();
	}

	@Override
	public String linkAccount(Long mobileNo, Long accountNo, Integer otp) throws AccountException {
		List<BankAccountEntity> accountEntityList = accountRepository.findByMobileNumber(mobileNo);
		BankAccountEntity bankAccountEntity = null;
		if (accountEntityList.isEmpty()) {
			throw new AccountException("account.NOT_EXIST");
		}

		for (BankAccountEntity entity : accountEntityList) {
			if (entity.getAccountNumber().equals(accountNo)) {
				bankAccountEntity = entity;
				break;
			}
		}

		if (bankAccountEntity == null) {
			throw new AccountException("account.MISMATCH");
		}

		String id = digitalBankAccountRepository.findLastById();
		String[] parts = id.split("-");
		String p1 = parts[0];
		String p2 = parts[1];

		int dId = Integer.parseInt(p2) + 1;
		String digitalId = p1 + "-" + dId;

		DigitalBankAccountEntity digitalBankAccountEntity = new DigitalBankAccountEntity();
		digitalBankAccountEntity.setDigitalBankingId(digitalId);
		digitalBankAccountEntity.setUser(bankAccountEntity.getUserEntity());
		digitalBankAccountEntity.setBankAccountEntity(bankAccountEntity);
		digitalBankAccountEntity.setAccountType(bankAccountEntity.getAccountType());

		if (digitalBankAccountRepository.findByAccountNo(accountNo) != null) {
			throw new AccountException("digitalId.EXIST");
		}

		if (otpUtility.sendOTP().equals(otp)) {
			digitalBankAccountRepository.save(digitalBankAccountEntity);
			return "Account linked successfully " + digitalBankAccountEntity.getDigitalBankingId();
		} else {
			throw new AccountException("otp.MISMATCH");
		}
	}

	@Override
	public double checkBalance(Long mobileNo, Long accountNo) throws AccountException {
		List<DigitalBankAccountEntity> entityList = digitalBankAccountRepository.findByMobileNo(mobileNo);
		if (entityList.isEmpty()) {
			throw new AccountException("account_NOT_EXIST");
		}

		DigitalBankAccountEntity digitalBankAccountEntity = null;
		for (DigitalBankAccountEntity accountEntity : entityList) {
			if (accountEntity.getBankAccountEntity().getAccountNumber().equals(accountNo)) {
				digitalBankAccountEntity = accountEntity;
				break;
			}
		}

		if (digitalBankAccountEntity == null) {
			throw new AccountException("NO_ACCOUNT_IS_LINKED");
		}

		return digitalBankAccountEntity.getBankAccountEntity().getBalance();
	}

	@Override
	public String fundTransfer(TransactionDTO transactionDTO) throws AccountException {
		List<BankAccountEntity> senderList = accountRepository.findByMobileNumber(transactionDTO.getPaidFrom());
		if (senderList.isEmpty()) {
			throw new AccountException("sender.Account_NOT_FOUND");
		}

		BankAccountEntity senderAccount = null;
		for (BankAccountEntity bankAccountEntity : senderList) {
			if (bankAccountEntity.getAccountNumber().equals(transactionDTO.getSenderAccountNumber())) {
				senderAccount = bankAccountEntity;
				break;
			}
		}

		if (senderAccount == null) {
			throw new AccountException("sender.Account_NOT_Linked");
		}

		List<BankAccountEntity> receiverList = accountRepository.findByMobileNumber(transactionDTO.getPaidTo());
		if (receiverList.isEmpty()) {
			throw new AccountException("receiver.Account_NOT_FOUND");
		}

		BankAccountEntity receiverAccount = null;
		for (BankAccountEntity bankAccountEntity : receiverList) {
			if (bankAccountEntity.getAccountNumber().equals(transactionDTO.getReceiverAccountNumber())) {
				receiverAccount = bankAccountEntity;
				break;
			}
		}

		if (receiverAccount == null) {
			throw new AccountException("receiver.Account_NOT_Linked");
		}

		if (senderAccount.getBalance() < transactionDTO.getAmount()) {
			throw new AccountException("fund.INSUFFICIENT");
		}

		senderAccount.setBalance(senderAccount.getBalance() - transactionDTO.getAmount());
		receiverAccount.setBalance(receiverAccount.getBalance() + transactionDTO.getAmount());

		TransactionEntity entity = new TransactionEntity();
		entity.setTransactionId(transactionDTO.getTransactionId());
		entity.setSenderAccountNumber(transactionDTO.getSenderAccountNumber());
		entity.setReceiverAccountNumber(transactionDTO.getReceiverAccountNumber());
		entity.setPaidTo(transactionDTO.getPaidTo());
		entity.setPaidFrom(transactionDTO.getPaidFrom());
		entity.setModeOfTransaction(transactionDTO.getModeOfTransaction());
		entity.setAmount(transactionDTO.getAmount());
		entity.setRemarks(transactionDTO.getRemarks());

		transactionRepository.save(entity);

		return "Transaction successful";
	}

	@Override
	public List<TransactionDTO> accountStatement(Long mobileNo) throws AccountException {
		List<TransactionEntity> list = transactionRepository.findByMobileNumber(mobileNo);
		if (list.isEmpty()) {
			throw new AccountException("NO_ACTIVE_TRANSACTIONS");
		}
		List<TransactionDTO> dtos = new ArrayList<>();
		for (TransactionEntity entity : list) {
			TransactionDTO transactionDTO = new TransactionDTO();
			transactionDTO.setTransactionId(entity.getTransactionId());
			transactionDTO.setSenderAccountNumber(entity.getSenderAccountNumber());
			transactionDTO.setReceiverAccountNumber(entity.getReceiverAccountNumber());
			transactionDTO.setPaidTo(entity.getPaidTo());
			transactionDTO.setPaidFrom(entity.getPaidFrom());
			transactionDTO.setModeOfTransaction(entity.getModeOfTransaction());
			transactionDTO.setAmount(entity.getAmount());
			transactionDTO.setRemarks(entity.getRemarks());
			transactionDTO.setTransactionDateTime(entity.getTransactionDateTime());
			dtos.add(transactionDTO);
		}
		return dtos;
	}
}
