package com.cdac.training.banking.demo.utility;

import javax.security.auth.login.AccountException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class AccountGlobalException {

    private static final Logger logger = LoggerFactory.getLogger(AccountGlobalException.class);

    // Existing exception handlers...

    @ExceptionHandler(Exception.class)
    public void handleGeneralException(Exception exception) {
        logger.error("An unexpected error occurred", exception);
        // Handle exception and return ResponseEntity
    }

    @ExceptionHandler(AccountException.class)
    public void handleAccountException(AccountException exception) {
        logger.error("Account error occurred: {}", exception.getMessage());
        // Handle exception and return ResponseEntity
    }
    


    // Other exception handlers...
}
