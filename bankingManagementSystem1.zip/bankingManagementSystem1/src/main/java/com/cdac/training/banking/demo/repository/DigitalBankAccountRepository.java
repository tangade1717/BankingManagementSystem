package com.cdac.training.banking.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cdac.training.banking.demo.entity.DigitalBankAccountEntity;
@Repository
public interface DigitalBankAccountRepository extends CrudRepository<DigitalBankAccountEntity, String> {

	@Query("select d from DigitalBankAccountEntity d where d.bankAccountEntity.accountNumber = :accountNumber")
	DigitalBankAccountEntity findByAccountNo(@Param("accountNumber") Long accountNumber);

	@Query("select m from DigitalBankAccountEntity m where m.user.mobileNumber = :mobileNumber")
	List<DigitalBankAccountEntity> findByMobileNo(@Param("mobileNumber") Long mobileNumber);

	@Query(value = "select max(d.digitalBankingId) from DigitalBankAccountEntity d")
	Long findMaxDigitalBankingId();

	Optional<DigitalBankAccountEntity> findByDigitalBankingId(String digitalBankingId);

}
