package com.cdac.training.banking.demo.utility;

import java.time.LocalDateTime;

public final class ErrorInformation {

	private final String errorMessage;
	private final int errorCode;
	private final LocalDateTime errorTimeStamp;

	// Constructor
	public ErrorInformation(String errorMessage, int errorCode, LocalDateTime errorTimeStamp) {
		if (errorMessage == null || errorMessage.trim().isEmpty()) {
			throw new IllegalArgumentException("Error message cannot be null or empty");
		}
		if (errorCode <= 0) {
			throw new IllegalArgumentException("Error code must be a positive integer");
		}
		if (errorTimeStamp == null) {
			throw new IllegalArgumentException("Error timestamp cannot be null");
		}

		this.errorMessage = errorMessage;
		this.errorCode = errorCode;
		this.errorTimeStamp = errorTimeStamp;
	}

	// Getters
	public String getErrorMessage() {
		return errorMessage;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public LocalDateTime getErrorTimeStamp() {
		return errorTimeStamp;
	}
}
