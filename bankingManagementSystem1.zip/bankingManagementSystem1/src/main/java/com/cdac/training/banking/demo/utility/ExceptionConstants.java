package com.cdac.training.banking.demo.utility;

public class ExceptionConstants {
	// Example error messages
	public static final String USER_NOT_FOUND = "USER_NOT_FOUND";
	public static final String INVALID_DOB = "DOB_INVALID";
	public static final String ACCOUNT_ALREADY_EXISTS = "ACCOUNT_ALREADY_EXISTS";
	public static final String USERID_ALREADY_PRESENT = "USERID_ALREADY_PRESENT";
	public static final String AUTHENTICATION_FAILED = "AUTHENTICATION_FAILED";

	// Example error codes
	public static final int GENERAL_ERROR_CODE = 1000;
	public static final int NOT_FOUND_ERROR_CODE = 404;
	public static final int AUTHENTICATION_ERROR_CODE = 401;
	public static final int VALIDATION_ERROR_CODE = 400;
}
