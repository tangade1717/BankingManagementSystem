package com.cdac.training.banking.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cdac.training.banking.demo.entity.TransactionEntity;

public interface TransactionRepository extends CrudRepository<TransactionEntity, Integer> {

	@Query("select m from TransactionEntity m where m.paidTo = :mobileNumber or m.paidFrom = :mobileNumber")
	List<TransactionEntity> findByMobileNumber(@Param("mobileNumber") Long mobileNumber);

}
