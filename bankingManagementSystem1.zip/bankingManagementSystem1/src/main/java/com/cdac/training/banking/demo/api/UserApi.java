package com.cdac.training.banking.demo.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.cdac.training.banking.demo.dto.LoginDTO;
import com.cdac.training.banking.demo.dto.UserDTO;
import com.cdac.training.banking.demo.service.UserService;

import java.util.List;

import javax.security.auth.login.AccountException;

@RestController
@RequestMapping("/cdac")
@CrossOrigin(origins = "http://localhost:3000")
@Validated
public class UserApi {

	private final UserService userService;
	private final Environment environment;

	@Autowired
	public UserApi(UserService userService, Environment environment) {
		this.userService = userService;
		this.environment = environment;
	}

	@PostMapping(value = "/users")
	public ResponseEntity<String> createUser(@Validated @RequestBody UserDTO userDTO) throws AccountException {
		userService.createUser(userDTO);
		String msg = environment.getProperty("userAPI_BOOKING_SUCCESS") + userDTO.getUserId();
		return new ResponseEntity<>(msg, HttpStatus.CREATED);
	}

	@PostMapping(value = "/users/login")
	public ResponseEntity<Boolean> loginUser(@RequestBody LoginDTO loginDTO) throws AccountException {
		Boolean loggedIn = userService.loginUser(loginDTO);
		return new ResponseEntity<>(loggedIn, HttpStatus.OK);
	}

	@GetMapping(value = "/users/{userId}")
	public ResponseEntity<UserDTO> getUserProfile(@PathVariable String userId) throws AccountException {
		UserDTO userDTO = userService.getUserProfile(userId);
		return new ResponseEntity<>(userDTO, HttpStatus.OK);
	}

	@GetMapping(value = "/users/all")
	public ResponseEntity<List<UserDTO>> showAllUsers() throws AccountException {
		List<UserDTO> userList = userService.showAllUsers();
		return new ResponseEntity<>(userList, HttpStatus.OK);
	}
}