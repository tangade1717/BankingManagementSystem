package com.cdac.training.banking.demo.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin(origins = "http://localhost:3000")
@Entity
@Table(name = "bank_account")
public class BankAccountEntity {

	@Id
	@Column(name = "account_number")
	private Long accountNumber;

	@Column(name = "bank_name")
	private String bankName;

	@Column(name = "balance")
	private Double balance;

	@Column(name = "account_type")
	private String accountType;

	@Column(name = "ifsc_code")
	private String ifscCode;

	@Column(name = "opening_date")
	private LocalDate openingDate;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "mobile_number")
	private UserEntity userEntity;

	// Getters and Setters
	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public LocalDate getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}

	public UserEntity getUserEntity() {
		return userEntity;
	}

	public void setUserEntity(UserEntity userEntity) {
		this.userEntity = userEntity;
	}
}
