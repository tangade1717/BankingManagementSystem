package com.cdac.training.banking.demo.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.security.auth.login.AccountException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cdac.training.banking.demo.dto.LoginDTO;
import com.cdac.training.banking.demo.dto.UserDTO;
import com.cdac.training.banking.demo.entity.UserEntity;
import com.cdac.training.banking.demo.repository.UserRepository;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public String createUser(UserDTO userDTO) throws AccountException {
        // Check if a user with the same mobile number already exists
        Optional<UserEntity> optionalUser = userRepository.findByMobileNumber(userDTO.getMobileNumber());
        if (optionalUser.isPresent()) {
            throw new AccountException("USER ALREADY EXISTS");
        }

        // Validate date of birth to ensure user is at least 18 years old
        LocalDate eighteenYearsAgo = LocalDate.now().minusYears(18);
        if (userDTO.getDateOfBirth().isAfter(eighteenYearsAgo)) {
            throw new AccountException("DOB_INVALID");
        }

        // Check if the user ID is already present
        Optional<UserEntity> existingUser = userRepository.findByUserId(userDTO.getUserId());
        if (existingUser.isPresent()) {
            throw new AccountException("USERID_ALREADY_PRESENT");
        }

        // Create a new UserEntity from UserDTO
        UserEntity newUserEntity = convertToEntity(userDTO);

        // Save the new user entity
        UserEntity savedUser = userRepository.save(newUserEntity);

        return savedUser.getMobileNumber().toString();
    }

    @Override
    public boolean loginUser(LoginDTO loginDTO) throws AccountException {
        // Find user by mobile number
        Optional<UserEntity> optionalUser = userRepository.findByMobileNumber(loginDTO.getMobileNumber());
        if (optionalUser.isEmpty()) {
            throw new AccountException("USER NOT FOUND");
        }

        UserEntity userEntity = optionalUser.get();

        // Verify password
        if (userEntity.getPassword().equals(loginDTO.getPassword())) {
            return true; // Authentication successful
        } else {
            throw new AccountException("AUTHENTICATION_FAILED");
        }
    }

    @Override
    public UserDTO getUserProfile(String userId) throws AccountException {
        // Find user by user ID
        Optional<UserEntity> userEntityOptional = userRepository.findByUserId(userId);
        if (userEntityOptional.isEmpty()) {
            throw new AccountException("USERID_NOT_FOUND");
        }

        // Convert UserEntity to UserDTO
        return convertToDTO(userEntityOptional.get());
    }

    @Override
    public List<UserDTO> showAllUsers() throws AccountException {
        // Retrieve all users
        List<UserEntity> userList = userRepository.findAll();
        if (userList.isEmpty()) {
            throw new AccountException("NO_USERS_FOUND");
        }

        // Convert list of UserEntity to list of UserDTO
        return userList.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // Utility method to convert UserDTO to UserEntity
    private UserEntity convertToEntity(UserDTO dto) {
        UserEntity entity = new UserEntity();
        entity.setUserId(dto.getUserId());
        entity.setAccountHolderName(dto.getAccountHolderName());
        entity.setCommunicationAddress(dto.getCommunicationAddress());
        entity.setDateOfBirth(dto.getDateOfBirth());
        entity.setEmail(dto.getEmail());
        entity.setGender(dto.getGender());
        entity.setMobileNumber(dto.getMobileNumber());
        entity.setPan(dto.getPan());
        // Password should not be included in DTOs or Entities in plain text in real-world scenarios
        entity.setPassword(dto.getPassword());
        return entity;
    }

    // Utility method to convert UserEntity to UserDTO
    private UserDTO convertToDTO(UserEntity entity) {
        UserDTO dto = new UserDTO();
        dto.setUserId(entity.getUserId());
        dto.setAccountHolderName(entity.getAccountHolderName());
        dto.setCommunicationAddress(entity.getCommunicationAddress());
        dto.setDateOfBirth(entity.getDateOfBirth());
        dto.setEmail(entity.getEmail());
        dto.setGender(entity.getGender());
        dto.setMobileNumber(entity.getMobileNumber());
        dto.setPan(entity.getPan());
        // Exclude password for security reasons
        return dto;
    }
}
