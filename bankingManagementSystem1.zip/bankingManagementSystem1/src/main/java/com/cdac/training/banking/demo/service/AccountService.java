package com.cdac.training.banking.demo.service;

import java.util.List;

import javax.security.auth.login.AccountException;

import com.cdac.training.banking.demo.dto.BankAccountDTO;
import com.cdac.training.banking.demo.dto.TransactionDTO;

public interface AccountService {

	String createAccount(BankAccountDTO accountDTO) throws AccountException;

	List<BankAccountDTO> listAccounts(Long mobileNo) throws AccountException;

	String linkAccount(Long mobileNo, Long accountNo) throws AccountException;

	List<TransactionDTO> accountStatement(Long mobileNo) throws AccountException;

	double checkBalance(Long mobileNo, Long accountNo) throws AccountException;

	String fundTransfer(TransactionDTO transactionDTO) throws AccountException;

	String linkAccount(Long mobileNo, Long accountNo, Integer otp) throws AccountException;
}
