package com.cdac.training.banking.demo.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.cdac.training.banking.demo.dto.BankAccountDTO;
import com.cdac.training.banking.demo.dto.TransactionDTO;
import com.cdac.training.banking.demo.service.AccountService;

import java.util.List;

import javax.security.auth.login.AccountException;

@RestController
@RequestMapping("/bank")
@Validated
@CrossOrigin(origins = "http://localhost:3000")
public class AccountApi {

	private final AccountService accountService;

	@Autowired
	public AccountApi(AccountService accountService) {
		this.accountService = accountService;
	}

	@PostMapping(value = "/accounts")
	public ResponseEntity<String> createAccount(@Validated @RequestBody BankAccountDTO accountDTO)
			throws AccountException {
		String result = accountService.createAccount(accountDTO);
		return new ResponseEntity<>(result, HttpStatus.CREATED);
	}

	@GetMapping(value = "/accounts/{mobileNo}")
	public ResponseEntity<List<BankAccountDTO>> listAccounts(@PathVariable Long mobileNo) throws AccountException {
		List<BankAccountDTO> accounts = accountService.listAccounts(mobileNo);
		return new ResponseEntity<>(accounts, HttpStatus.OK);
	}

	@PostMapping(value = "/accounts/{mobileNo}/{accountNo}")
	public ResponseEntity<String> linkAccount(@PathVariable Long mobileNo, @PathVariable Long accountNo)
			throws AccountException {
		String id = accountService.linkAccount(mobileNo, accountNo);
		return new ResponseEntity<>(id, HttpStatus.CREATED);
	}

	@PostMapping(value = "/accounts/{mobileNo}/{accountNo}/{otp}")
	public ResponseEntity<String> linkAccountWithOTP(@PathVariable Long mobileNo, @PathVariable Long accountNo,
			@PathVariable Integer otp) throws AccountException {
		String id = accountService.linkAccount(mobileNo, accountNo, otp);
		return new ResponseEntity<>(id, HttpStatus.CREATED);
	}

	@GetMapping(value = "/accounts/balance/{mobileNo}/{accountNo}")
	public ResponseEntity<Double> checkBalance(@PathVariable Long mobileNo, @PathVariable Long accountNo)
			throws AccountException {
		double balance = accountService.checkBalance(mobileNo, accountNo);
		return new ResponseEntity<>(balance, HttpStatus.OK);
	}

	@PostMapping(value = "/accounts/fundtransfer")
	public ResponseEntity<String> fundTransfer(@Validated @RequestBody TransactionDTO transactionDTO)
			throws AccountException {
		String result = accountService.fundTransfer(transactionDTO);
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	@GetMapping(value = "/accounts/statement/{mobileNo}")
	public ResponseEntity<List<TransactionDTO>> accountStatement(@PathVariable Long mobileNo)
			throws AccountException {
		List<TransactionDTO> statement = accountService.accountStatement(mobileNo);
		return new ResponseEntity<>(statement, HttpStatus.OK);
	}
}