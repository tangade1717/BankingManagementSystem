package com.cdac.training.banking.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cdac.training.banking.demo.entity.BankAccountEntity;

public interface AccountRepository extends CrudRepository<BankAccountEntity, Long> {

	@Query("select m from BankAccountEntity m where m.userEntity.mobileNumber = :mobileNumber")
	List<BankAccountEntity> findByMobileNumber(@Param("mobileNumber") Long mobileNumber);

	@Query("select m from BankAccountEntity m where m.accountNumber = :accountNumber and m.userEntity.mobileNumber = :mobileNumber")
	BankAccountEntity findByMobileNumberAndAccountNumber(@Param("mobileNumber") Long mobileNumber,
			@Param("accountNumber") Long accountNumber);
}
