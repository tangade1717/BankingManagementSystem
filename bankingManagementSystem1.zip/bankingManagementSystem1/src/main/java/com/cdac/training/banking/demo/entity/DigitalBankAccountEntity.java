package com.cdac.training.banking.demo.entity;

import org.springframework.web.bind.annotation.CrossOrigin;

import jakarta.persistence.*;

@CrossOrigin(origins = "http://localhost:3000")
@Entity
@Table(name = "digital_bank_account")
public class DigitalBankAccountEntity {

	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "digital_banking_id", nullable = false,updatable = false)
	private String digitalBankingId;


	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mobile_number")
	private UserEntity user;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "account_number")
	private BankAccountEntity bankAccountEntity;

	@Column(name = "account_type")
	private String accountType;

	// Getters and Setters
	// (Include getters and setters for all fields)

	public String getDigitalBankingId() {
		return digitalBankingId;
	}

	public void setDigitalBankingId(String digitalId) {
		this.digitalBankingId = digitalId;
	}

	public UserEntity getUser() {
		return user;
	}

	public void setUser(UserEntity user) {
		this.user = user;
	}

	public BankAccountEntity getBankAccountEntity() {
		return bankAccountEntity;
	}

	public void setBankAccountEntity(BankAccountEntity bankAccountEntity) {
		this.bankAccountEntity = bankAccountEntity;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	
}
