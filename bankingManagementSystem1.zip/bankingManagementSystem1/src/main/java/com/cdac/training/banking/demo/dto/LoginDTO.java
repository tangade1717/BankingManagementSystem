package com.cdac.training.banking.demo.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class LoginDTO {

    @NotNull(message = "Mobile number cannot be null")
    private Long mobileNumber;

    @NotNull(message = "Password cannot be null")
    @Size(min = 6, message = "Password should be at least 6 characters long")
    private String password;

    // Default constructor
    public LoginDTO() {
    }

    // Parameterized constructor
    public LoginDTO(Long mobileNumber, String password) {
        this.mobileNumber = mobileNumber;
        this.password = password;
    }

    // Getters
    public Long getMobileNumber() {
        return mobileNumber;
    }

    public String getPassword() {
        return password;
    }

    // Setters
    public void setMobileNumber(Long mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // toString method
    @Override
    public String toString() {
        return "LoginDTO [mobileNumber=" + mobileNumber + ", password=" + password + "]";
    }
}
