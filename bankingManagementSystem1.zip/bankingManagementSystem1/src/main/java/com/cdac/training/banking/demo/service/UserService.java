package com.cdac.training.banking.demo.service;

import java.util.List;

import javax.security.auth.login.AccountException;

import com.cdac.training.banking.demo.dto.LoginDTO;
import com.cdac.training.banking.demo.dto.UserDTO;

public interface UserService {

	/**
	 * Authenticate user based on login credentials.
	 * 
	 * @param loginDTO The login credentials containing mobile number and password.
	 * @return true if login is successful, false otherwise.
	 * @throws AccountException if there is an issue with authentication.
	 */
	public boolean loginUser(LoginDTO loginDTO) throws AccountException;

	/**
	 * Retrieve user profile details based on userId.
	 * 
	 * @param userId The unique identifier of the user.
	 * @return UserDTO containing user profile information.
	 * @throws AccountException if user profile retrieval fails.
	 */
	public UserDTO getUserProfile(String userId) throws AccountException;

	/**
	 * Create a new user with the provided details.
	 * 
	 * @param userDTO The user details to create.
	 * @return String indicating success or failure message.
	 * @throws AccountException if user creation fails.
	 */
	public String createUser(UserDTO userDTO) throws AccountException;

	/**
	 * Retrieve a list of all users.
	 * 
	 * @return List of UserDTO containing all users.
	 * @throws AccountException if retrieval of users fails.
	 */
	public List<UserDTO> showAllUsers() throws AccountException;
}
