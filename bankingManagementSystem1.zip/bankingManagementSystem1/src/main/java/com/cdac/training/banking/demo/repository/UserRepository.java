package com.cdac.training.banking.demo.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cdac.training.banking.demo.entity.UserEntity;

public interface UserRepository extends JpaRepository<UserEntity, Long> {

    // Method to find a user by mobile number
    Optional<UserEntity> findByMobileNumber(Long mobileNumber);

    // Method to find a user by user ID
    Optional<UserEntity> findByUserId(String userId);
}