package com.cdac.training.banking.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
